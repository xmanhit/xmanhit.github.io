Romeolight WebPconv version 5.1
WebP converter
http://www.romeolight.com/products/webpconv/

--------------------------------------------------------

WebPconv is a free software. The WebP is a new file format for web by Google.
This application provides easy operaion front end system based on google webp libraries.
You can check detail about webp format from google developer's site.
https://developers.google.com/speed/webp/


[Environment]
Microsoft(R) Windows 8(R) *Recommended
Microsoft(R) Windows 7(R) 
Microsoft(R) Windows(R) Vista(R)

To launch this application, you need Microsoft(R).NetFrameWork 3.5 and over.
If you using Windows XP or don't have that, please download and install
.NetFramework runtime from Microsoft's site below.

http://www.microsoft.com/en-us/download/details.aspx?id=25150

--------------------------------------------------------
Copyright 2015 Romeolight, All rights reserved.
http://www.romeolight.com
https://www.facebook.com/romeolight/
